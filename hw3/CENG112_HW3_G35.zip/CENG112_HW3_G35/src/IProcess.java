// G35 -
// 250201039 - Burak TUTUMLU
// 250201046 - Bekir Y�R�K

public interface IProcess {
	
	public String getType();
	
	public int getPriority();
	
	public String  toString();
}
